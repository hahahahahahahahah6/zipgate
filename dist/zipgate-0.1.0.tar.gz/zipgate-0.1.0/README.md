# zipgate

Audit wheels and zips for malformed ZIP64 structures — before your installer chokes on them.

## Why

Two real incidents:

- [astral-sh/uv#19440](https://github.com/astral-sh/uv/issues/19440): a 5.8 GiB PyTorch ROCm nightly wheel failed to install with `zip64 extended information field was too long`.
- [pypa/wheel#692](https://github.com/pypa/wheel/issues/692): `wheel tags` in wheel 0.47.0 wrote an illegal ZIP64 extra field into local file headers of retagged wheels.

`zipfile` silently tolerates these malformations; installers don't. zipgate parses local file headers and central directory entries by hand and checks the ZIP64 extra field (`0x0001`) against APPNOTE 4.5.3:

- **SPURIOUS_ZIP64_LOCAL** — a local header carries ZIP64 extra data for fields that aren't `0xFFFF`/`0xFFFFFFFF` (the wheel 0.47.0 bug).
- **ZIP64_LENGTH_MISMATCH** — the extra field is longer (or shorter) than the maxed-out fields require (the uv#19440 class).
- **SIZE_MISMATCH** — central directory and local header disagree on sizes.
- **MISSING_ZIP64** — a `0xFFFFFFFF` size with no ZIP64 extra to back it.

## Install

```bash
pip install zipgate
```

## Use

```bash
$ zipgate mywheel-1.0-py3-none-any.whl
VALID: mywheel-1.0-py3-none-any.whl

$ zipgate suspicious.whl
INVALID: suspicious.whl
  [SPURIOUS_ZIP64_LOCAL] pkg-1.0.dist-info/WHEEL: local header carries 8-byte ZIP64 extra but no size field is 0xFFFFFFFF
```

Exit codes: `0` all valid, `1` at least one invalid, `2` at least one unreadable.

## Verified against the real bug

Built a wheel with `zipfile.ZIP64_LIMIT` lowered (the [wheel#692 MRE trick](https://github.com/pypa/wheel/issues/692)), retagged with `wheel tags`:

| | zipgate verdict |
|---|---|
| original wheel | VALID |
| retagged with wheel 0.47.0 | **INVALID** (`SPURIOUS_ZIP64_LOCAL`) |
| retagged with wheel 0.48.0 | VALID |

## License

MIT
